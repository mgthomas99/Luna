const chalk = require("chalk");
const clear = require("clear");
const rl = require("readline-sync");

enum Direction {
  North = 0b1000,
  East  = 0b0100,
  South = 0b0010,
  West  = 0b0001,
  NorthEast = Direction.North | Direction.East,
  NorthWest = Direction.North | Direction.West,
  SouthEast = Direction.South | Direction.East,
  SouthWest = Direction.South | Direction.West,
}

type TileTypeID = number;
type TileData = number;
type TileContext = {
  data: number;
  x: number;
  y: number;
}

abstract class TileType {
  public init(ctx: TileContext) : void { }
  public tick(ctx: TileContext) : void { }
  abstract isSolid(ctx: TileContext) : boolean;
  abstract model(ctx: TileContext) : string[][] | string;
}

class TileMap {
  public readonly depth : number;
  public readonly width : number;
  public data : Uint8Array;

  public constructor(depth: number, width: number) {
    this.depth = depth;
    this.width = width;
    this.data = new Uint8Array(depth * width);
    this.data.fill(0);
  }

  public setTileData(index: number, data: TileData) : void {
    data &= 0b00111111;
    this.data[index] = (this.getTileTypeID(index) << 6) | data;
  }

  public setTileTypeID(index: number, type: TileTypeID) : void {
    type &= 0b00000011;
    this.data[index] = this.getTileData(index) | (type << 6);
  }

  public getTileData(index: number) : TileData {
    return this.data[index] & 0b00111111;
  }

  public getTileTypeID(index: number) : TileTypeID {
    return (this.data[index] & 0b11000000) >> 6;
  }

  public getTileIndex(x: number, y: number) : number {
    return y * this.width + x;
  }
}

class Player {
  public facing: Direction;
  public x: number;
  public y: number;
  public constructor(x: number, y: number) {
    this.facing = Direction.North;
    this.x = x;
    this.y = y;
  }
}

function direction2icon (dir: Direction) {
  switch (dir) {
    case Direction.North : return "^";
    case Direction.South : return "V";
    case Direction.East : return ">";
    case Direction.West : return "<";
  }
}

function direction2string (dir: Direction) {
  switch (dir) {
    case Direction.NorthEast : return "North-East";
    case Direction.NorthWest : return "North-West";
    case Direction.SouthEast : return "South-East";
    case Direction.SouthWest : return "South-West";
    case Direction.North : return "North";
    case Direction.South : return "South";
    case Direction.East : return "East";
    case Direction.West : return "West";
  }
}

const map = new TileMap(
    (process as any).stdout.rows - 2,
    (process as any).stdout.columns - 1);
const ply = new Player(0, 0);

const tiletypes = {
  0: (function () {
    return new class extends TileType {
      model(info) {
        return chalk.green(info.data & 0b010000 ? ',' : '.');
      }
      isSolid() {
        return false;
      }
      tick(info: TileContext) {
        if (! (info.data & 0b100000)) {
          info.data += ~~ (Math.random() * 0b10000);
          info.data |= 0b100000;
        } else if (! (info.data & 0b010000)) {
          info.data += 1;
        }
      }
    };
  })(),
  1: (function () {
    return new class extends TileType {
      model(info) {
        return chalk.white('#');
      }
      isSolid() {
        return true;
      }
    }
  })()
};

function getRenderString() {
  for (let y = 0; y < map.depth; y++) {
    for (let x = 0; x < map.width; x++) {
      if (x === ply.x && y === ply.y) {
        (process as any).stdout.write("@");
      } else {
        const tile_index = map.getTileIndex(x, y);
        const tile_type = map.getTileTypeID(tile_index);
        const tile_data = map.getTileData(tile_index);
        const tile = tiletypes[tile_type];
        const model = tile.model({ data: tile_data, x, y });

        if (typeof model === "string") {
          (process as any).stdout.write(model);
        } else { }
      }
    }
  }
}

function render() {
  clear();

  console.log(getRenderString());
}

function update() {
  const c = rl.question();

  if (c === "w") {
    ply.y -= 1;
  }
  else if (c === "s") {
    ply.y += 1;
  }
  else if (c === "a") {
    ply.x -= 1;
  }
  else if (c === "d") {
    ply.x += 1;
  }
  else if (c === "W") {
    ply.facing = Direction.North;
  }
  else if (c === "S") {
    ply.facing = Direction.South;
  }
  else if (c === "A") {
    ply.facing = Direction.East;
  }
  else if (c === "D") {
    ply.facing = Direction.West;
  }
  else if (c === "e") {
    map.setTileTypeID(0, map.getTileTypeID(0) ? 0b00 : 0b01);
  }

  for (let i = 0; i < map.data.length; i++) {
    const tile_type = tiletypes[map.getTileTypeID(i)] as TileType;
    const tile_data = map.getTileData(i);
    const ctx = {
      data: tile_data,
      x: i % map.width,
      y: Math.floor(i / map.width)
    };
    tile_type.tick(ctx);
    map.setTileData(i, ctx.data);
  }
}

while (true) {
  render();
  update();
}
